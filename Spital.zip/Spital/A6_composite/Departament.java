package A6_composite;

public interface Departament {
    void afiseaza(String indentare);
}