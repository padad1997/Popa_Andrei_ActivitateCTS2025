package spital.laborator;

public interface RetetaPrototype {
    RetetaPrototype duplicare();
}