package strategy;

public interface Plata {
    void plateste(double suma);
}