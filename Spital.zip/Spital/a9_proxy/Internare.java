package proxy;

public interface Internare {
    void interneaza(Pacient pacient);
}