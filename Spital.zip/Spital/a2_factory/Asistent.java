
package a2_factory;

public class Asistent implements PersonalSpital {
    @Override
    public void Descriere() {
        System.out.println("Asistent: asista medicii si ingrijeste pacientii.");
    }
}
