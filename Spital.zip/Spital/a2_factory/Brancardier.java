
package a2_factory;

public class Brancardier implements PersonalSpital {
    @Override
    public void Descriere() {
        System.out.println("Brancardier: transport pacienti intre saloane.");
    }
}
