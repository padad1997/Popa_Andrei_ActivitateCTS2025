
package a2_factory;

public interface PersonalSpital {
    void Descriere();
}
