
package a2_factory;

public class Medic implements PersonalSpital {
    @Override
    public void Descriere() {
        System.out.println("Medic: consulta si trateaza pacientii.");
    }
}
