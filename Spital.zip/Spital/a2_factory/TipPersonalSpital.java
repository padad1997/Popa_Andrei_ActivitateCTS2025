
package a2_factory;

public enum TipPersonalSpital {
    Brancardier,
    Asistent,
    Medic
}
