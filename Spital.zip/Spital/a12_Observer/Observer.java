package observer;

public interface Observer {
    void primesteNotificare(String mesaj);
}