package command;

public interface Comanda {
    void executa();
}