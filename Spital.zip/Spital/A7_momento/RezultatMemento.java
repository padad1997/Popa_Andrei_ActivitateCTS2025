package memento;

public class RezultatMemento {
    private final String stare;

    public RezultatMemento(String stare) {
        this.stare = stare;
    }

    public String getStare() {
        return stare;
    }
}