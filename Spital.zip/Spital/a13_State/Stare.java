package state;

public interface Stare {
    void aplicaStare(Pacient pacient);
}