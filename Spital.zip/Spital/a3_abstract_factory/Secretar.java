
package a3_abstract_factory;

public class Secretar implements PersonalSpital {
    @Override
    public void Descriere() {
        System.out.println("Secretar din categoria personal non-medical.");
    }
}
