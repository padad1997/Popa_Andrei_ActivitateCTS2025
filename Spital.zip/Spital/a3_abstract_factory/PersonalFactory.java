
package a3_abstract_factory;

public interface PersonalFactory {
    PersonalSpital CreazaPersonal(String Tip);
}
