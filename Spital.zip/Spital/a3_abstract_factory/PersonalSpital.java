
package a3_abstract_factory;

public interface PersonalSpital {
    void Descriere();
}
