
package a3_abstract_factory;

public class Registrator implements PersonalSpital {
    @Override
    public void Descriere() {
        System.out.println("Registrator din categoria personal non-medical.");
    }
}
