
package a3_abstract_factory;

public class Asistent implements PersonalSpital {
    @Override
    public void Descriere() {
        System.out.println("Asistent din categoria personal medical.");
    }
}
