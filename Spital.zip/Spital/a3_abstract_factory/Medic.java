
package a3_abstract_factory;

public class Medic implements PersonalSpital {
    @Override
    public void Descriere() {
        System.out.println("Medic din categoria personal medical.");
    }
}
