package prototype;

public interface RetetaPrototype {
    RetetaPrototype duplicare();
}