package composite;

public interface UnitateSpital {
    void afiseazaStructura(String indentare);
}