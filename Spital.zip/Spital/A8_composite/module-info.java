/**
 * 
 */
/**
 * @author andreidanielpopa
 *
 */
module composite {
}